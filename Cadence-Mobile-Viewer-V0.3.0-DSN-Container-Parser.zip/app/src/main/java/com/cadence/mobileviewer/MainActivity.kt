package com.cadence.mobileviewer

import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import java.io.File

class MainActivity : ComponentActivity() {
    private external fun nativeParseFile(path: String): String
    companion object { init { System.loadLibrary("cadence_probe") } }
    private lateinit var resultView: TextView
    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) inspect(uri)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        root.addView(TextView(this).apply { text = "Cadence Mobile Viewer 0.3.0\nOrCAD DSN Container Parser"; textSize = 22f })
        root.addView(TextView(this).apply {
            text = "\n本版本可完整读取 OLE/CFBF 目录结构，识别原理图页面流和封装定义流。元件实例、引脚、网络和连线的记录级解码仍在后续集成。\n"
            textSize = 15f
        })
        root.addView(Button(this).apply { text = "选择 OrCAD .DSN 文件"; setOnClickListener { picker.launch(arrayOf("*/*")) } })
        resultView = TextView(this).apply { text = "\n等待选择文件"; textSize = 14f; setTextIsSelectable(true) }
        root.addView(resultView)
        setContentView(ScrollView(this).apply { addView(root) })
    }
    private fun inspect(uri: Uri) {
        resultView.text = "正在复制并解析完整文件……"
        Thread {
            try {
                val doc = DocumentFile.fromSingleUri(this, uri)
                val name = doc?.name ?: uri.lastPathSegment ?: "unknown"
                val temp = File(cacheDir, "cadence_input_${System.currentTimeMillis()}.dsn")
                contentResolver.openInputStream(uri)?.use { input -> temp.outputStream().use { output -> input.copyTo(output) } }
                    ?: throw IllegalStateException("无法打开所选文件")
                val report = "文件：$name\n大小：${temp.length()} bytes\n\n原生解析结果：\n${nativeParseFile(temp.absolutePath)}"
                temp.delete()
                runOnUiThread { resultView.text = report }
            } catch (e: Exception) {
                runOnUiThread { resultView.text = "读取或解析失败：${e.message}" }
            }
        }.start()
    }
}
