#include <jni.h>
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_set>
#include <vector>

namespace {
constexpr uint32_t FREESECT = 0xFFFFFFFFu;
constexpr uint32_t ENDOFCHAIN = 0xFFFFFFFEu;
constexpr uint32_t FATSECT = 0xFFFFFFFDu;
constexpr uint32_t DIFSECT = 0xFFFFFFFCu;

uint16_t u16(const std::vector<uint8_t>& b, size_t p) {
    if (p + 2 > b.size()) throw std::runtime_error("truncated CFBF header");
    return uint16_t(b[p]) | (uint16_t(b[p + 1]) << 8);
}
uint32_t u32(const std::vector<uint8_t>& b, size_t p) {
    if (p + 4 > b.size()) throw std::runtime_error("truncated CFBF header");
    return uint32_t(b[p]) | (uint32_t(b[p + 1]) << 8) | (uint32_t(b[p + 2]) << 16) | (uint32_t(b[p + 3]) << 24);
}
uint64_t u64(const std::vector<uint8_t>& b, size_t p) {
    return uint64_t(u32(b, p)) | (uint64_t(u32(b, p + 4)) << 32);
}
std::string utf16leToUtf8(const uint8_t* p, size_t bytes) {
    std::string out;
    for (size_t i = 0; i + 1 < bytes; i += 2) {
        uint32_t cp = uint32_t(p[i]) | (uint32_t(p[i + 1]) << 8);
        if (cp == 0) break;
        if (cp < 0x20) cp = 0x20;
        if (cp >= 0xD800 && cp <= 0xDBFF && i + 3 < bytes) {
            uint32_t lo = uint32_t(p[i + 2]) | (uint32_t(p[i + 3]) << 8);
            if (lo >= 0xDC00 && lo <= 0xDFFF) { cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00); i += 2; }
        }
        if (cp < 0x80) out.push_back(char(cp));
        else if (cp < 0x800) { out.push_back(char(0xC0 | (cp >> 6))); out.push_back(char(0x80 | (cp & 0x3F))); }
        else if (cp < 0x10000) { out.push_back(char(0xE0 | (cp >> 12))); out.push_back(char(0x80 | ((cp >> 6) & 0x3F))); out.push_back(char(0x80 | (cp & 0x3F))); }
        else { out.push_back(char(0xF0 | (cp >> 18))); out.push_back(char(0x80 | ((cp >> 12) & 0x3F))); out.push_back(char(0x80 | ((cp >> 6) & 0x3F))); out.push_back(char(0x80 | (cp & 0x3F))); }
    }
    return out;
}
struct DirEntry { std::string name; uint8_t type=0; uint32_t left=FREESECT, right=FREESECT, child=FREESECT, start=ENDOFCHAIN; uint64_t size=0; };

class CfbfReader {
public:
    explicit CfbfReader(const std::string& path) {
        std::ifstream f(path, std::ios::binary | std::ios::ate);
        if (!f) throw std::runtime_error("cannot open selected file");
        auto n = f.tellg();
        if (n < 512 || uint64_t(n) > 512ull * 1024 * 1024) throw std::runtime_error("file size outside supported range (512 B..512 MB)");
        data.resize(size_t(n)); f.seekg(0); f.read(reinterpret_cast<char*>(data.data()), n);
        if (!f || std::memcmp(data.data(), "\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1", 8) != 0) throw std::runtime_error("not a CFBF/OLE compound file");
        uint16_t major = u16(data, 26), byteOrder = u16(data, 28), sectorShift = u16(data, 30), miniShift = u16(data, 32);
        if (byteOrder != 0xFFFE || (major != 3 && major != 4) || (sectorShift != 9 && sectorShift != 12) || miniShift != 6)
            throw std::runtime_error("unsupported CFBF header parameters");
        sectorSize = 1u << sectorShift; miniSectorSize = 1u << miniShift;
        uint32_t numFat = u32(data, 44), firstDir = u32(data, 48), firstDifat = u32(data, 68), numDifat = u32(data, 72);
        std::vector<uint32_t> difat;
        for (size_t i=0;i<109;i++) { uint32_t x=u32(data,76+i*4); if (x!=FREESECT && x!=ENDOFCHAIN && x!=FATSECT && x!=DIFSECT) difat.push_back(x); }
        uint32_t sid=firstDifat;
        for (uint32_t i=0; i<numDifat && sid!=ENDOFCHAIN && sid!=FREESECT; ++i) {
            auto s=sector(sid); size_t count=sectorSize/4;
            for(size_t j=0;j+1<count;j++){uint32_t x=rd32(s,j*4); if(x!=FREESECT && x!=ENDOFCHAIN && x!=FATSECT && x!=DIFSECT) difat.push_back(x);}
            sid=rd32(s,(count-1)*4);
        }
        if (difat.size() < numFat) throw std::runtime_error("incomplete FAT sector list");
        for (uint32_t i=0;i<numFat;i++) { auto s=sector(difat[i]); for(size_t j=0;j<sectorSize/4;j++) fat.push_back(rd32(s,j*4)); }
        auto dirBytes = readChain(firstDir, fat);
        for(size_t p=0;p+128<=dirBytes.size();p+=128) {
            uint16_t nameBytes = uint16_t(dirBytes[p+64]) | (uint16_t(dirBytes[p+65])<<8);
            uint8_t type=dirBytes[p+66];
            DirEntry e;
            if(type==0) { entries.push_back(e); continue; } e.name = nameBytes>=2 && nameBytes<=64 ? utf16leToUtf8(dirBytes.data()+p,nameBytes-2) : "";
            e.type=type; e.left=rd32(dirBytes,p+68); e.right=rd32(dirBytes,p+72); e.child=rd32(dirBytes,p+76); e.start=rd32(dirBytes,p+116);
            e.size=uint64_t(rd32(dirBytes,p+120)); if(major==4) e.size=u64(dirBytes,p+120);
            entries.push_back(e);
        }
        if(entries.empty() || entries[0].type!=5) throw std::runtime_error("CFBF root directory entry missing");
        walk(entries[0].child, "", 0);
    }
    std::string summary() const {
        size_t dirs=0, streams=0, pageCount=0, packageCount=0, activeEntries=0; uint64_t totalStreamBytes=0;
        for(const auto& e: entries) if(e.type!=0) ++activeEntries;
        for(const auto& x: rows) { if(x.type==1) ++dirs; if(x.type==2){++streams; totalStreamBytes+=x.size; if(startsWith(x.path,"Views/SCHEMATICS/Pages/")) ++pageCount; if(startsWith(x.path,"Packages/")) ++packageCount;} }
        std::ostringstream o;
        o << "CFBF/OLE compound container parsed successfully\n";
        o << "Directory entries: " << activeEntries << "\nSubdirectories: " << dirs << "\nStreams: " << streams << "\n";
        o << "Total stream bytes: " << totalStreamBytes << "\n";
        o << "OrCAD structure candidates:\n";
        for(const auto& x: rows) if(x.type==2 && (x.path=="DsnStream" || x.path=="Library" || x.path=="Cells Directory" || x.path=="Parts Directory" || x.path=="Views Directory" || x.path=="Packages Directory" || x.path=="AdminData"))
            o << "  " << x.path << " (" << x.size << " bytes)\n";
        o << "Schematic page streams: " << pageCount << "\n";
        for(const auto& x: rows) if(x.type==2 && startsWith(x.path,"Views/SCHEMATICS/Pages/")) o << "  - " << x.path.substr(23) << " (" << x.size << " B)\n";
        o << "Package definition streams: " << packageCount << "\n";
        o << "\nContainer parsing is complete; OrCAD record-level decoding (instances, pins, nets, wires) is not yet integrated.\n";
        return o.str();
    }
private:
    struct Row { std::string path; uint8_t type; uint64_t size; };
    std::vector<uint8_t> data; uint32_t sectorSize=512, miniSectorSize=64; std::vector<uint32_t> fat; std::vector<DirEntry> entries; std::vector<Row> rows; std::unordered_set<uint32_t> visited;
    static bool startsWith(const std::string& s,const std::string& p){return s.rfind(p,0)==0;}
    static uint32_t rd32(const std::vector<uint8_t>& b,size_t p){if(p+4>b.size())throw std::runtime_error("sector data truncated");return uint32_t(b[p])|(uint32_t(b[p+1])<<8)|(uint32_t(b[p+2])<<16)|(uint32_t(b[p+3])<<24);}
    std::vector<uint8_t> sector(uint32_t sid) const { uint64_t off=(uint64_t(sid)+1)*sectorSize; if(off+sectorSize>data.size())throw std::runtime_error("sector index outside file"); return {data.begin()+off,data.begin()+off+sectorSize}; }
    std::vector<uint8_t> readChain(uint32_t start,const std::vector<uint32_t>& table) const {
        std::vector<uint8_t> out; std::unordered_set<uint32_t> seen; uint32_t s=start;
        while(s!=ENDOFCHAIN && s!=FREESECT){ if(s>=table.size() || !seen.insert(s).second) throw std::runtime_error("invalid or cyclic CFBF sector chain"); auto b=sector(s); out.insert(out.end(),b.begin(),b.end()); if(out.size()>data.size()*2) throw std::runtime_error("CFBF chain exceeds safety limit"); s=table[s]; }
        return out;
    }
    void walk(uint32_t id,const std::string& parent,int depth){
        if(id==FREESECT || id==ENDOFCHAIN) return;
        if(id>=entries.size() || depth>64 || !visited.insert(id).second) throw std::runtime_error("invalid CFBF directory tree");
        const auto& e=entries[id]; if(e.type==0) throw std::runtime_error("directory tree references an empty entry"); walk(e.left,parent,depth+1);
        std::string path=parent.empty()?e.name:parent+"/"+e.name; rows.push_back({path,e.type,e.size});
        if(e.type==1) walk(e.child,path,depth+1);
        walk(e.right,parent,depth+1);
    }
};
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_cadence_mobileviewer_MainActivity_nativeParseFile(JNIEnv* env, jobject, jstring pathValue) {
    const char* path=env->GetStringUTFChars(pathValue,nullptr);
    std::string pathCopy=path?path:""; if(path) env->ReleaseStringUTFChars(pathValue,path);
    try { CfbfReader reader(pathCopy); auto s=reader.summary(); return env->NewStringUTF(s.c_str()); }
    catch(const std::exception& e){ std::string s="解析失败："+std::string(e.what()); return env->NewStringUTF(s.c_str()); }
}
