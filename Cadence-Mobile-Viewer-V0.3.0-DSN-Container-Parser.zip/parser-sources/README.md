# Parser integration notes

## Current V0.3.0

The Android app contains an independently authored C++20 CFBF/OLE reader. It validates the complete compound-file container, traverses FAT/DIFAT chains and the directory tree, and reports OrCAD stream/page/package counts. It does **not** decode OrCAD page records yet.

## Planned record-level parser

Candidate: https://github.com/Werni2A/OpenOrCadParser

- Focuses on OrCAD Capture `*.DSN` / `*.DBK` and symbol libraries `*.OLB` / `*.OBK`.
- C++20.
- MIT license.
- Archived read-only on 2026-05-31.
- Dependencies listed upstream include compoundfilereader, fmt, magic_enum, nameof, spdlog, TinyXML2, and Boost.Program_options for the CLI. The CLI dependency should not be brought into the Android app.
- Upstream source has a `Container` API that extracts CFBF streams and parses database streams, but Android filesystem, temporary-file, threading, logging, and dependency integration need an explicit NDK adaptation.
- Upstream README points to Cadence Capture 17.4 XSD files under `tools/capture/tclscripts/capDB/dsn.xsd` and `olb.xsd` for format reference.

Do not mark record-level parsing as complete until the actual `PAD_v14.DSN` sample yields verified component, pin, net, wire, and page data. Preserve upstream LICENSE and dependency notices if its code is vendored.
