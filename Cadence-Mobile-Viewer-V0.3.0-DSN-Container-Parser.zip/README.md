# Cadence Mobile Viewer V0.3.0 — DSN Container Parser

Android offline prototype for inspecting OrCAD Capture `.DSN` files.

## What V0.3.0 actually implements

- Android Storage Access Framework file picker.
- Copies the selected document to the app cache so native code can read the **complete file**, not just the first 4096 bytes.
- JNI bridge to a C++20 parser.
- CFBF/OLE header validation and FAT/DIFAT directory-chain traversal.
- Parses the compound-file directory tree and lists stream paths and sizes.
- Recognizes OrCAD-related streams such as `DsnStream`, `Library`, `Cells Directory`, `Parts Directory`, `Views Directory`, and `Packages Directory`.
- Counts schematic page streams under `Views/SCHEMATICS/Pages` and package-definition streams under `Packages`.
- Runs offline after installation; no server or network access is used by the app.

## Validation against the supplied sample

Sample: `PAD_v14.DSN` (2,397,184 bytes)

Host-side C++20 test of the same native parser source produced:

- 195 active directory entries
- 15 subdirectories
- 179 streams
- 2,324,291 total stream bytes
- 16 schematic page streams
- 138 package-definition streams

The parser also found the expected OrCAD container streams including `DsnStream`, `Library`, `Cells Directory`, `Parts Directory`, `Views Directory`, and `Packages Directory`.

## Important scope boundary

V0.3.0 is a **CFBF/OLE container and directory parser**, not yet a complete OrCAD schematic decoder. It does not yet decode page-level records into component instances, reference designators, pins, nets, wires, or geometry, and it does not render a schematic. The UI explicitly reports this limitation.

The next stage is to integrate and adapt the MIT-licensed OpenOrCadParser record parser, audit its dependencies for Android NDK compatibility, then validate actual component/pin/net extraction against this sample. OpenOrCadParser is C++20 and targets OrCAD Capture DSN/DBK and OLB/OBK, but documents that its coverage is not exhaustive. Its source is not silently represented as already integrated in this package.

Upstream reference: https://github.com/Werni2A/OpenOrCadParser
License: MIT (upstream parser license applies only if/when its source is integrated; this V0.3.0 container reader is independently authored in this project).

## Build

Use the included GitHub Actions workflow `android.yml`, or build with Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17, Android SDK 35, NDK 27.2.12479018, and CMake 3.22.1.

## Safety / limits

- The native reader caps selected input files at 512 MiB to avoid unbounded memory use.
- This build targets `.DSN` CFBF/OLE containers. Allegro `.BRD` parsing is not changed by this release.
- The Android APK has not been built in this environment; run the included workflow to verify the Android/NDK build.
