# Upstream parser source integration plan

No upstream implementation is copied into this scaffold yet. Sources must be pinned to reviewed immutable commits and accompanied by exact LICENSE/NOTICE files before vendoring.

## DSN: OpenOrCadParser (MIT)
https://github.com/Werni2A/OpenOrCadParser
C++20, CMake/vcpkg. Upstream README lists Boost.Program_options (CLI only), compoundfilereader, fmt, magic_enum, nameof, spdlog, TinyXML2. Exclude CLI/desktop tools; retain parser library and required CFBF implementation. Audit transitive licenses. Validate with OrCAD Capture 17.4 DSN and XML/XSD exports.

## BRD: KiCad Allegro importer (GPL-3.0-or-later)
https://gitlab.com/kicad/code/kicad
Docs: https://dev-docs.kicad.org/en/import-formats/allegro/
Documented support: Allegro 16.0–17.5, including 17.4. Extract only headless Allegro reader and minimum PCB/geometry model. Do not include KiCad GUI/wxWidgets. Preserve GPL and third-party notices.

## Secondary reference
https://github.com/bernayigit/brd_parser
README says Boost >= 1.71; Qt6 is optional for GUI only. Verify exact LICENSE before copying source.

## V0.2.0 implemented scope
Only native header/signature probing:
- CFBF/OLE signature candidate for Capture DSN/OLB.
- Allegro 17.4 magic 0x00140900 and marker `all` at offset 0xF8.
This is not full file parsing.
