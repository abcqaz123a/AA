# Cadence Mobile Viewer V0.2.0 — Parser Validation Scaffold

## Implemented
- Android local document picker.
- Offline JNI/C++20 file-header probe.
- Allegro 17.4 magic check (0x00140900) and `all` marker at offset 0xF8.
- OLE Compound File signature check as a first-stage Capture DSN/OLB candidate test.
- GitHub Actions debug APK build for ARM64 and ARMv7.

## Not implemented yet
- CFBF directory/stream parsing and OrCAD object decoding.
- Allegro object-block decoding.
- PCB/schematic rendering.
- Component, pin, net and layer extraction.

A signature match is not proof of valid or fully supported design data.

## Build
Upload project contents to repository root. Run Actions -> Cadence Mobile Viewer - Android Build.
Download artifact `Cadence-Mobile-Viewer-v0.2.0-debug`.

## Samples required
Please upload one anonymized OrCAD Capture 17.4 `.dsn` and one Allegro 17.4 `.brd`.
If possible, also provide Capture XML export/XSD and board Gerber/netlist exports for cross-checking.
Only share designs you are authorized to disclose.
