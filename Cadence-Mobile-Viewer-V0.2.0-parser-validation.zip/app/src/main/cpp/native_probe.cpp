#include <jni.h>
#include <cstdint>
#include <sstream>
#include <string>
static uint32_t be32(const jbyte* p) {
 return (uint32_t(uint8_t(p[0]))<<24)|(uint32_t(uint8_t(p[1]))<<16)|(uint32_t(uint8_t(p[2]))<<8)|uint32_t(uint8_t(p[3]));
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_cadence_mobileviewer_MainActivity_nativeProbe(JNIEnv* env, jobject, jbyteArray input) {
 const jsize n=env->GetArrayLength(input);
 if(n<=0) return env->NewStringUTF("ERROR: empty header");
 jbyte* b=env->GetByteArrayElements(input,nullptr);
 std::ostringstream o; o<<"Header bytes read: "<<n<<"\n";
 const bool cfbf=n>=8 && uint8_t(b[0])==0xD0 && uint8_t(b[1])==0xCF && uint8_t(b[2])==0x11 && uint8_t(b[3])==0xE0 && uint8_t(b[4])==0xA1 && uint8_t(b[5])==0xB1 && uint8_t(b[6])==0x1A && uint8_t(b[7])==0xE1;
 if(cfbf) o<<"OLE CFBF signature detected. Candidate: OrCAD Capture DSN/OLB family. Next: parse directory and verify streams.";
 else if(n>=4 && be32(b)==0x00140900) {
   o<<"Allegro magic 0x00140900: V174 / 17.4\n";
   if(n>0xFA && b[0xF8]=='a' && b[0xF9]=='l' && b[0xFA]=='l') o<<"Header marker at 0xF8: all (matches KiCad format docs).\n";
   else o<<"Header marker at 0xF8 not present in this header window.\n";
   o<<"Next: decode string table and object blocks.";
 } else if(n>=0xFB && b[0xF8]=='a' && b[0xF9]=='l' && b[0xFA]=='l') o<<"Allegro-like marker found; version magic unknown.";
 else o<<"Unknown signature; insufficient evidence to classify.";
 env->ReleaseByteArrayElements(input,b,JNI_ABORT);
 return env->NewStringUTF(o.str().c_str());
}
