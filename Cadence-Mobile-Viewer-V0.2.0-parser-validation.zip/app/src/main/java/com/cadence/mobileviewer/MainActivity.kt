package com.cadence.mobileviewer

import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile

class MainActivity : ComponentActivity() {
    private external fun nativeProbe(header: ByteArray): String
    companion object { init { System.loadLibrary("cadence_probe") } }
    private lateinit var resultView: TextView
    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) inspect(uri)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        root.addView(TextView(this).apply { text = "Cadence Mobile Viewer 0.2.0\nNative Parser Validation"; textSize = 22f })
        root.addView(TextView(this).apply {
            text = "\nTarget: OrCAD Capture 17.4 DSN / Allegro 17.4 BRD.\nThis build probes signatures only; full parsing is not yet integrated.\n"
            textSize = 15f
        })
        root.addView(Button(this).apply { text = "选择 .dsn / .brd 文件"; setOnClickListener { picker.launch(arrayOf("*/*")) } })
        resultView = TextView(this).apply { text = "\n等待选择文件"; textSize = 14f }
        root.addView(resultView)
        setContentView(ScrollView(this).apply { addView(root) })
    }
    private fun inspect(uri: Uri) {
        try {
            val doc = DocumentFile.fromSingleUri(this, uri)
            val name = doc?.name ?: uri.lastPathSegment ?: "unknown"
            val header = contentResolver.openInputStream(uri)?.use { input ->
                val bytes = ByteArray(4096); val count = input.read(bytes)
                if (count > 0) bytes.copyOf(count) else byteArrayOf()
            } ?: byteArrayOf()
            resultView.text = "文件：$name\n大小：${doc?.length() ?: -1} bytes\n\nNative probe:\n${nativeProbe(header)}\n\n文件头识别不等于完整解析成功。"
        } catch (e: Exception) { resultView.text = "读取失败：${e.message}" }
    }
}
